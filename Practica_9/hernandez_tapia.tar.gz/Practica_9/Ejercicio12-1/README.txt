Modo de ejecucion:
./Nombre seconds