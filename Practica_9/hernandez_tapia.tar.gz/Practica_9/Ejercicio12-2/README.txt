Modo de ejecucion:
./Nombre