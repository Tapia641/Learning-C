Ejecutable:

./Tarea_6