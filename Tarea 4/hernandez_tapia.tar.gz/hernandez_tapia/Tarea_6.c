#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <sys/sem.h>
#include <unistd.h>

int leer_car(){
    char letra;
    char almacen[80];
    scanf("%s",almacen);
    sscanf(almacen, "%c", &letra);
    return letra;
}

int main(int argc, const char *argv[])
{
    //crear memoria
    key_t key  = ftok("/temp",40);
    int shmid = shmget(key, sizeof(int), 0660|IPC_CREAT);
    //attach y declaracion puntero
    int *tam = (int*)shmat(shmid, NULL, 0);
    //escribir
	*tam = 100;
    char buffer[25];

    while(1)
    {
        printf("\nIntroduzca m para modificar el texto, v para visualizarla y t para terminar\n");
        switch(leer_car())
        {
            case 't': /*Libera la memoria compartida */
                shmctl(shmid, IPC_RMID, 0);
                exit(0);
            case 'v':/*Visualiza la variable*/
                printf("Texto recibido = %s\n",buffer);
                break;
            case 'm':
                printf("Ingrese texto a enviar atraves de la memoria:\n");
                scanf("%s",buffer);
                break;
            default:
                printf("Se introdujo una letra incorrecta = \n");
                break;
        }
    }

    return 0;
}